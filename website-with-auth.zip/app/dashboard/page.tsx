import { getSession } from "@/lib/session"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { logout } from "@/lib/actions"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Activity, Target, Award, Clock } from "lucide-react"
import dynamic from "next/dynamic"
import { Suspense } from "react"

// Dynamically import the CricketShotClassifier with no SSR
const CricketShotClassifier = dynamic(() => import("./CricketShotClassifier"), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-[400px] bg-gray-50 rounded-lg border border-gray-200">
      <div className="text-center">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-green-600 border-r-transparent mb-4"></div>
        <p className="text-gray-600">Loading shot classifier...</p>
      </div>
    </div>
  ),
})

export default async function DashboardPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const { user } = session

  return (
    <div className="flex min-h-screen flex-col">
      <header className="border-b bg-green-800">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center">
            <Target className="h-6 w-6 mr-2 text-white" />
            <h1 className="text-lg font-bold text-white">CrickBoost Dashboard</h1>
          </div>
          <form action={logout}>
            <Button type="submit" variant="outline" className="bg-white hover:bg-gray-100 text-green-800">
              Log out
            </Button>
          </form>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        <div className="container py-8">
          <div className="rounded-lg border bg-card p-8 shadow-sm mb-10 bg-gradient-to-r from-green-50 to-blue-50">
            <h2 className="text-2xl font-bold text-green-800">Welcome, {user.name}!</h2>
            <p className="mt-2 text-muted-foreground">
              Ready to analyze and improve your cricket technique? Use the shot classifier below to get started.
            </p>
          </div>

          <Tabs defaultValue="shot-analysis" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="shot-analysis" className="text-base">
                Shot Analysis
              </TabsTrigger>
              <TabsTrigger value="progress" className="text-base">
                Progress Tracking
              </TabsTrigger>
              <TabsTrigger value="drills" className="text-base">
                Recommended Drills
              </TabsTrigger>
            </TabsList>

            <TabsContent value="shot-analysis" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Sessions</CardTitle>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">12</div>
                    <p className="text-xs text-muted-foreground">+2 from last week</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Shots Analyzed</CardTitle>
                    <Activity className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">245</div>
                    <p className="text-xs text-muted-foreground">+22% from last month</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Top Shot</CardTitle>
                    <Award className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">Cover Drive</div>
                    <p className="text-xs text-muted-foreground">92% accuracy</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Improvement Area</CardTitle>
                    <Target className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">Pull Shot</div>
                    <p className="text-xs text-muted-foreground">Needs practice</p>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-8">
                <Card className="border-green-200">
                  <CardHeader>
                    <CardTitle className="text-xl text-green-800">Cricket Shot Classifier</CardTitle>
                    <CardDescription>
                      Position yourself in front of the camera and play your cricket shots to get real-time feedback
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Suspense
                      fallback={
                        <div className="flex items-center justify-center h-[400px] bg-gray-50 rounded-lg">
                          <div className="text-center">
                            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-green-600 border-r-transparent mb-4"></div>
                            <p className="text-gray-600">Loading shot classifier...</p>
                          </div>
                        </div>
                      }
                    >
                      <CricketShotClassifier />
                    </Suspense>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="progress" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Your Progress</CardTitle>
                  <CardDescription>Track your improvement over time across different cricket shots</CardDescription>
                </CardHeader>
                <CardContent className="pl-2">
                  <div className="h-[300px] w-full flex items-center justify-center border rounded-md p-4">
                    <div className="flex flex-col items-center text-center">
                      <BarChart className="h-16 w-16 text-gray-300 mb-4" />
                      <h3 className="text-lg font-medium">Progress Charts Coming Soon</h3>
                      <p className="text-sm text-muted-foreground max-w-md mt-2">
                        Continue practicing with the shot classifier to build your performance data and unlock detailed
                        progress tracking.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="drills" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recommended Practice Drills</CardTitle>
                  <CardDescription>Personalized drills based on your performance data</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-lg border p-4">
                      <h3 className="font-medium">Front Foot Drive Practice</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Focus on your front foot movement and follow-through to improve your drive shots.
                      </p>
                      <div className="mt-2">
                        <Button variant="outline" size="sm" className="text-xs">
                          View Drill
                        </Button>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="font-medium">Pull Shot Technique</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Work on your backfoot positioning and timing for more effective pull shots.
                      </p>
                      <div className="mt-2">
                        <Button variant="outline" size="sm" className="text-xs">
                          View Drill
                        </Button>
                      </div>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h3 className="font-medium">Defensive Stance Improvement</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Practice your defensive technique with these focused drills.
                      </p>
                      <div className="mt-2">
                        <Button variant="outline" size="sm" className="text-xs">
                          View Drill
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
